CREATE TABLE IF NOT EXISTS slider (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    subtitle VARCHAR(255) NOT NULL,
    img VARCHAR(255) NOT NULL
);

-- Insert default slider data
INSERT INTO slider (title, subtitle, img) VALUES
('Hayalindeki Hediyeler Burada', 'Renkli tasarımlarla fark yarat!', 'img/slider1.jpg'),
('Sevdiklerinizi Mutlu Edin', 'Özel tasarım ürünlerimizle tanışın.', 'img/slider2.jpg'),
('Çizgili Kareli Farkı', 'Kalite ve şıklık bir arada.', 'img/slider3.jpg');
