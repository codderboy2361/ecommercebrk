INSERT INTO products (title, price, category, img) VALUES
('Renkli Kupa', 79.99, 'kupa', 'img/kupa.jpg'),
('Mood Defter', 59.99, 'defter', 'img/defter.jpg'),
('Çizgili Tshirt', 99.99, 'tshirt', 'img/tshirt.jpg'),
('Sticker Paketi', 29.99, 'sticker', 'img/sticker.jpg'),
('Renkli Kalem Seti', 49.99, 'kalem', 'img/kalem.jpg'),
('Şık Çanta', 149.99, 'canta', 'img/canta.jpg'),
('Planlayıcı Ajanda', 89.99, 'ajanda', 'img/ajanda.jpg'),
('Paslanmaz Çelik Termos', 119.99, 'termos', 'img/termos.jpg'),
('Ahşap Masa Dekoru', 199.99, 'dekor', 'img/masa.jpg'),
('Telefon Kılıfı', 39.99, 'aksesuar', 'img/telefon-kilifi.jpg'),
('Motivasyon Kitabı', 69.99, 'kitap', 'img/kitap.jpg'),
('El Yapımı Duvar Süsü', 129.99, 'dekor', 'img/duvar-susu.jpg');
