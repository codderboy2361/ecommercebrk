-- Create the `admins` table
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the `users` table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(100) DEFAULT NULL,
    surname VARCHAR(100) DEFAULT NULL,
    phone VARCHAR(15) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the `products` table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(100) NOT NULL,
    img VARCHAR(255) NOT NULL,
    description TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the `cart` table
CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Create the `orders` table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    status ENUM('Hazırlanıyor', 'Kargoya Verildi', 'Teslim Edildi') DEFAULT 'Hazırlanıyor',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create the `order_items` table
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Insert sample data into the `admins` table
INSERT INTO admins (username, password) VALUES
('admin', '$2y$10$eImiTXuWVxfM37uY4JANjOe6kY9Q9Q9Q9Q9Q9Q9Q9Q9Q9Q9Q'); -- Replace with a hashed password

-- Insert sample data into the `users` table
INSERT INTO users (username, password, email) VALUES
('user1', '$2y$10$eImiTXuWVxfM37uY4JANjOe6kY9Q9Q9Q9Q9Q9Q9Q9Q9Q9Q', 'user1@example.com'), -- Replace with a hashed password
('user2', '$2y$10$eImiTXuWVxfM37uY4JANjOe6kY9Q9Q9Q9Q9Q9Q9Q9Q9Q9Q', 'user2@example.com');

-- Insert sample data into the `products` table
INSERT INTO products (title, price, category, img) VALUES
('Renkli Kupa', 79.99, 'Kupa', 'img/kupa.jpg'),
('Mood Defter', 59.99, 'Defter', 'img/defter.jpg'),
('Çizgili Tshirt', 99.99, 'Tshirt', 'img/tshirt.jpg'),
('Sticker Paketi', 29.99, 'Sticker', 'img/sticker.jpg'),
('Renkli Kalem Seti', 49.99, 'Kalem', 'img/kalem.jpg');

-- Insert sample data into the `orders` table
INSERT INTO orders (user_id, total_price, status) VALUES
(1, 159.98, 'Hazırlanıyor'),
(2, 79.99, 'Kargoya Verildi');

-- Insert sample data into the `order_items` table
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(1, 1, 2, 79.99),
(2, 2, 1, 79.99);
