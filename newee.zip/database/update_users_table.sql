-- Add `name`, `surname`, and `phone` columns to the `users` table if they don't already exist
ALTER TABLE users 
ADD COLUMN name VARCHAR(100) DEFAULT NULL,
ADD COLUMN surname VARCHAR(100) DEFAULT NULL,
ADD COLUMN phone VARCHAR(15) DEFAULT NULL;
