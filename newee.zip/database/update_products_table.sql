-- Add a `description` column to the `products` table if it doesn't already exist
ALTER TABLE products 
ADD COLUMN description TEXT DEFAULT NULL;
