ALTER TABLE orders ADD COLUMN status ENUM('Hazırlanıyor', 'Kargoya Verildi', 'Teslim Edildi') DEFAULT 'Hazırlanıyor';
