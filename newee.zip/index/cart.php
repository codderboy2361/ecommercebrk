<?php
require 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sepet</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Quicksand', sans-serif;
            background: linear-gradient(135deg, #e0f2f1, #b2dfdb); /* Light teal gradient */
            color: #2c3e50; /* Navy blue */
            margin: 0;
            padding: 0;
        }

        .cart-container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background: #ffffff; /* White */
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .cart-header {
            text-align: center;
            font-size: 2rem;
            color: #00796b; /* Teal */
            margin-bottom: 20px;
        }

        .cart-items {
            margin-bottom: 20px;
        }

        .cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #ddd;
        }

        .cart-item:last-child {
            border-bottom: none;
        }

        .cart-item img {
            height: 60px;
            border-radius: 5px;
        }

        .cart-item-details {
            flex: 1;
            margin-left: 15px;
        }

        .cart-item-title {
            font-size: 1.2rem;
            font-weight: bold;
            color: #2c3e50; /* Navy blue */
        }

        .cart-item-price {
            color: #00796b; /* Teal */
            font-size: 1rem;
            margin-top: 5px;
        }

        .cart-item-quantity {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 10px;
        }

        .cart-item-quantity button {
            background-color: #00796b; /* Teal */
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }

        .cart-item-quantity button:hover {
            background-color: #004d40; /* Dark teal */
        }

        .cart-item-remove {
            background: none;
            border: none;
            color: #00796b; /* Teal */
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .cart-item-remove:hover {
            color: #004d40; /* Dark teal */
        }

        .cart-footer {
            text-align: right;
        }

        .cart-total {
            font-size: 1.5rem;
            font-weight: bold;
            color: #2c3e50; /* Navy blue */
            margin-bottom: 20px;
        }

        .checkout-button {
            background-color: #00796b; /* Teal */
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .checkout-button:hover {
            background-color: #004d40; /* Dark teal */
        }

        .notification {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #4caf50; /* Success green */
            color: white;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            font-size: 1.2rem;
            text-align: center;
            z-index: 1000;
            display: none;
            animation: fadeInOut 3s ease forwards;
        }

        .notification.error {
            background-color: #e74c3c; /* Error red */
        }

        @keyframes fadeInOut {
            0% {
                opacity: 0;
                transform: translate(-50%, -60%);
            }
            10%, 90% {
                opacity: 1;
                transform: translate(-50%, -50%);
            }
            100% {
                opacity: 0;
                transform: translate(-50%, -40%);
            }
        }
    </style>
</head>
<body>
    <?php include('header.php'); ?>

    <div class="cart-container">
        <h1 class="cart-header">Sepetiniz</h1>
        <div id="cart-items">
            <!-- Cart items will be dynamically loaded here -->
        </div>
        <div id="cart-total">Toplam: ₺0.00</div>
        <button class="checkout-button" onclick="checkout()">Siparişi Tamamla</button>
    </div>

    <div class="notification" id="notification"></div>

    <script>
        function loadCartItems() {
            fetch('get-cart-items.php?userId=<?= urlencode($userId) ?>')
                .then(response => response.json())
                .then(data => {
                    const cartItemsContainer = document.getElementById('cart-items');
                    const cartTotalElement = document.getElementById('cart-total');
                    cartItemsContainer.innerHTML = '';
                    let total = 0;

                    if (data.success && data.cartItems.length > 0) {
                        data.cartItems.forEach(item => {
                            const cartItem = document.createElement('div');
                            cartItem.className = 'cart-item';
                            cartItem.innerHTML = `
                                <img src="${item.img}" alt="${item.title}">
                                <div class="cart-item-details">
                                    <div class="cart-item-title">${item.title}</div>
                                    <div class="cart-item-price">₺${parseFloat(item.price).toFixed(2).replace('.', ',')}</div>
                                    <div class="cart-item-quantity">
                                        <button onclick="updateQuantity(${item.product_id}, -1)">-</button>
                                        <span>${item.quantity}</span>
                                        <button onclick="updateQuantity(${item.product_id}, 1)">+</button>
                                    </div>
                                </div>
                                <button class="cart-item-remove" onclick="removeItem(${item.product_id})">Kaldır</button>
                            `;
                            cartItemsContainer.appendChild(cartItem);
                            total += item.price * item.quantity;
                        });
                        cartTotalElement.textContent = `Toplam: ₺${total.toFixed(2).replace('.', ',')}`;
                    } else {
                        cartItemsContainer.innerHTML = '<p>Sepetiniz boş.</p>';
                        cartTotalElement.textContent = 'Toplam: ₺0.00';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showNotification('Bir hata oluştu. Lütfen tekrar deneyin.', true);
                });
        }

        function updateQuantity(productId, change) {
            fetch('update-cart-item.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ productId, change, userId: <?= json_encode($userId) ?> })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    loadCartItems();
                    showNotification('Ürün miktarı güncellendi!');
                } else {
                    showNotification('Ürün miktarı güncellenirken bir hata oluştu.', true);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Bir hata oluştu. Lütfen tekrar deneyin.', true);
            });
        }

        function removeItem(productId) {
            fetch('remove-cart-item.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ productId, userId: <?= json_encode($userId) ?> })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    loadCartItems();
                    showNotification('Ürün başarıyla kaldırıldı!');
                } else {
                    showNotification('Ürün kaldırılırken bir hata oluştu.', true);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Bir hata oluştu. Lütfen tekrar deneyin.', true);
            });
        }

        function checkout() {
            fetch('create-order.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId: <?= json_encode($userId) ?> })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification('Sipariş başarıyla oluşturuldu!');
                    loadCartItems();
                } else {
                    showNotification('Sipariş oluşturulamadı.', true);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Bir hata oluştu. Lütfen tekrar deneyin.', true);
            });
        }

        function showNotification(message, isError = false) {
            const notification = document.getElementById('notification');
            notification.textContent = message;
            notification.className = `notification ${isError ? 'error' : ''}`;
            notification.style.display = 'block';

            setTimeout(() => {
                notification.style.display = 'none';
            }, 3000);
        }

        document.addEventListener('DOMContentLoaded', loadCartItems);
    </script>
</body>
</html>