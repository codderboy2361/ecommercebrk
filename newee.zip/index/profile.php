<?php
require '../admin/db.php'; // Include database connection

session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];

// Fetch user details
function fetchUserDetails($pdo, $userId) {
    $stmt = $pdo->prepare("SELECT username, email, name, surname, phone FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch();
}

$user = fetchUserDetails($pdo, $userId);

if (!$user) {
    echo 'Kullanıcı bulunamadı.';
    exit;
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $name = trim($_POST['name']);
    $surname = trim($_POST['surname']);
    $phone = trim($_POST['phone']);

    // Validate inputs
    if (empty($username) || empty($email)) {
        $errorMessage = "Kullanıcı adı ve e-posta alanları zorunludur.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = "Geçerli bir e-posta adresi giriniz.";
    } else {
        // Update user details
        $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, name = ?, surname = ?, phone = ? WHERE id = ?");
        $stmt->execute([$username, $email, $name, $surname, $phone, $userId]);

        // Refresh user data
        $user = fetchUserDetails($pdo, $userId);

        $successMessage = "Profil başarıyla güncellendi.";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Quicksand', sans-serif;
            background: linear-gradient(135deg, #e0f2f1, #b2dfdb); /* Light teal gradient */
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            flex-shrink: 0;
        }

        main {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .profile-wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 30px;
            max-width: 800px;
            width: 100%;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .profile-section {
            width: 100%;
        }

        .profile-section h2 {
            text-align: center;
            color: #00796b;
            margin-bottom: 20px;
        }

        .profile-section p {
            font-size: 1rem;
            margin: 10px 0;
            text-align: center;
        }

        .profile-section p strong {
            color: #555;
        }

        .profile-section form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .profile-section label {
            font-weight: bold;
            color: #555;
        }

        .profile-section input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }

        .profile-section button {
            padding: 10px;
            background: #00796b; /* Teal */
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .profile-section button:hover {
            background: #004d40; /* Dark teal */
        }

        .success-message {
            text-align: center;
            color: #4caf50;
            margin-bottom: 20px;
        }

        .error-message {
            text-align: center;
            color: #00796b;
            margin-bottom: 20px;
        }

        footer {
            flex-shrink: 0;
            background: #00796b;
            color: white;
            text-align: center;
            padding: 10px;
            margin-top: auto;
        }
    </style>
</head>
<body>
    <?php include('header.php'); ?>

    <main>
        <div class="profile-wrapper">
            <div class="profile-section">
                <h2>Profil Bilgileri</h2>
                <p><strong>Kullanıcı Adı:</strong> <?= htmlspecialchars($user['username']) ?></p>
                <p><strong>E-posta:</strong> <?= htmlspecialchars($user['email']) ?></p>
                <p><strong>İsim:</strong> <?= htmlspecialchars($user['name'] ?? 'Belirtilmemiş') ?></p>
                <p><strong>Soyisim:</strong> <?= htmlspecialchars($user['surname'] ?? 'Belirtilmemiş') ?></p>
                <p><strong>Telefon:</strong> <?= htmlspecialchars($user['phone'] ?? 'Belirtilmemiş') ?></p>
            </div>

            <div class="profile-section">
                <h2>Bilgileri Güncelle</h2>
                <?php if (isset($successMessage)): ?>
                    <p class="success-message"><?= htmlspecialchars($successMessage) ?></p>
                <?php endif; ?>
                <?php if (isset($errorMessage)): ?>
                    <p class="error-message"><?= htmlspecialchars($errorMessage) ?></p>
                <?php endif; ?>
                <form method="POST">
                    <label for="username">Kullanıcı Adı</label>
                    <input type="text" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>

                    <label for="email">E-posta</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>

                    <label for="name">İsim</label>
                    <input type="text" id="name" name="name" value="<?= htmlspecialchars($user['name'] ?? '') ?>">

                    <label for="surname">Soyisim</label>
                    <input type="text" id="surname" name="surname" value="<?= htmlspecialchars($user['surname'] ?? '') ?>">

                    <label for="phone">Telefon Numarası</label>
                    <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">

                    <button type="submit">Güncelle</button>
                </form>
            </div>
        </div>
    </main>

    <?php include('footer.php'); ?>
</body>
</html>
