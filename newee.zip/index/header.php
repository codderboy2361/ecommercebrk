<?php
session_start();
require 'db.php';

// Fetch cart count for logged-in users
$cartCount = 0;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT SUM(quantity) AS cartCount FROM cart WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $cartCount = $stmt->fetchColumn();
    $cartCount = $cartCount !== null ? $cartCount : 0; // Ensure $cartCount is always an integer
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($product['title']) ? htmlspecialchars($product['title']) . ' | Çizgili Kareli' : 'Çizgili Kareli' ?></title>
  <link rel="stylesheet" href="style.css">
  <style>
    .product-detail {
      padding: 60px 0;
      background-color:rgb(139, 219, 209); /* Teal */
    }
    .product-detail-wrapper {
      display: flex;
      flex-wrap: wrap;
      gap: 40px;
      max-width: 1200px;
      margin: auto;
      align-items: flex-start;
    }
    .product-detail-wrapper img {
      width: 100%;
      max-width: 500px;
      border-radius: 10px;
    }
    .product-info {
      flex: 1;
      min-width: 280px;
    }

    .product-info h1 {
      font-size: 2rem;
      margin-bottom: 15px;
    }

    .product-info .price {
      color: #00796b; /* Teal */
      font-size: 1.5rem;
      margin-bottom: 10px;
    }

    .product-info p {
      font-size: 1rem;
      margin-bottom: 20px;
      line-height: 1.6;
    }

    .btn-secondary {
      background-color: #00796b; /* Teal */
      color: #fff;
      padding: 12px 24px;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
    }

    .comments {
      max-width: 1000px;
      margin: 50px auto 0;
      padding-top: 40px;
      border-top: 1px solid #ddd;
    }

    .comments h2 {
      margin-bottom: 20px;
    }

    .comment {
      background: #fafafa;
      padding: 15px;
      border-radius: 6px;
      margin-bottom: 10px;
      border: 1px solid #eee;
    }
    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px 40px;
      background: #fff;
      border-bottom: 1px solid #eee;
    }
    header .logo {
      font-size: 1.5rem;
      font-weight: bold;
      color: #00796b;
      text-decoration: none;
    }
    header form {
      display: flex;
      align-items: center;
    }
    header input[type="text"] {
      padding: 8px 12px;
      border: 2px solid rgba(255, 255, 255, 0.8);
      border-radius: 4px 0 0 4px;
      outline: none;
      font-size: 1rem;
      background-color: rgba(255, 255, 255, 0.5); /* Transparent background */
      color: #00796b;
      transition: all 0.3s ease;
    }

    header input[type="text"]::placeholder {
      color: #00796b; /* Match the theme */
    }

    header input[type="text"]:focus {
      background-color: rgba(255, 255, 255, 0.8);
      border-color: #00796b;
    }

    header button {
      padding: 8px 12px;
      background-color: rgba(255, 255, 255, 0.5); /* Transparent background */
      color: #00796b;
      border: 2px solid rgba(255, 255, 255, 0.8);
      border-radius: 0 4px 4px 0;
      cursor: pointer;
      font-weight: bold;
      transition: all 0.3s ease;
    }

    header button:hover {
      background-color: #00796b;
      color: white;
      border-color: #00796b;
    }

    header .nav-links {
      list-style: none;
      display: flex;
      gap: 15px;
    }

    header .nav-links li {
      display: inline-block;
    }

    header .nav-links a {
      text-decoration: none;
      color: #00796b;
      font-weight: bold;
      padding: 10px 15px;
      border: 2px solid #00796b;
      border-radius: 5px;
      transition: all 0.3s ease;
    }

    header .nav-links a:hover {
      background-color: #00796b;
      color: white;
    }
  </style>
</head>
<body>
  <header>
    <a href="index.php" class="logo">Çizgili Kareli</a>
    <ul class="nav-links">
      <li><a href="index.php">Ana Sayfa</a></li>
      <li><a href="products.php">Ürünler</a></li>
      <?php if (isset($_SESSION['user_id'])): ?>
        <li><a href="profile.php">Profilim</a></li>
        <li>
          <a href="cart.php">
            Sepet <span id="cart-count">(<?= $cartCount ?>)</span>
          </a>
        </li>
        <li><a href="logout.php">Çıkış Yap</a></li>
      <?php else: ?>
        <li><a href="login.php">Giriş Yap</a></li>
      <?php endif; ?>
    </ul>
  </header>
</body>
</html>