<?php
require '../admin/db.php';

$data = json_decode(file_get_contents('php://input'), true);
$userId = $data['userId'] ?? null;

if (!$userId) {
    echo json_encode(['success' => false, 'message' => 'Kullanıcı ID eksik.']);
    exit;
}

// Get cart items for the user
$stmt = $pdo->prepare("SELECT c.product_id, c.quantity, p.price FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?");
$stmt->execute([$userId]);
$cartItems = $stmt->fetchAll();

if (empty($cartItems)) {
    echo json_encode(['success' => false, 'message' => 'Sepetiniz boş.']);
    exit;
}

// Calculate the total price
$totalPrice = 0;
foreach ($cartItems as $item) {
    $totalPrice += $item['price'] * $item['quantity'];
}

// Create a new order
$stmt = $pdo->prepare("INSERT INTO orders (user_id, total_price) VALUES (?, ?)");
$stmt->execute([$userId, $totalPrice]);
$orderId = $pdo->lastInsertId();

// Add items to the order_items table
foreach ($cartItems as $item) {
    $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
    $stmt->execute([$orderId, $item['product_id'], $item['quantity'], $item['price']]);
}

// Clear the cart
$stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = ?");
$stmt->execute([$userId]);

echo json_encode(['success' => true]);
?>
