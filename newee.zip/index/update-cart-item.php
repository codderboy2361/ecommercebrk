<?php
require '../admin/db.php';

$data = json_decode(file_get_contents('php://input'), true);
$productId = $data['productId'] ?? null;
$change = filter_var($data['change'] ?? null, FILTER_VALIDATE_INT);
$userId = $data['userId'] ?? null;

if (!$productId || !$change || !$userId) {
    echo json_encode(['success' => false, 'message' => 'Eksik veya geçersiz parametreler.']);
    exit;
}

$stmt = $pdo->prepare("UPDATE cart SET quantity = quantity + ? WHERE user_id = ? AND product_id = ?");
$stmt->execute([$change, $userId, $productId]);

// Remove the item if quantity is 0 or less
$stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ? AND quantity <= 0");
$stmt->execute([$userId, $productId]);

echo json_encode(['success' => true, 'message' => '<span style="color: #00796b;">Ürün başarıyla güncellendi!</span>']);
?>
