<?php
require '../admin/db.php';

$data = json_decode(file_get_contents('php://input'), true);
$userId = filter_var($data['userId'] ?? null, FILTER_VALIDATE_INT);
$productId = filter_var($data['productId'] ?? null, FILTER_VALIDATE_INT);

if (!$userId || !$productId) {
    echo json_encode(['success' => false, 'message' => 'Eksik veya geçersiz parametreler.']);
    exit;
}

// Check if the product already exists in the cart
$stmt = $pdo->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
$stmt->execute([$userId, $productId]);
$cartItem = $stmt->fetch();

if ($cartItem) {
    // Update the quantity if the product is already in the cart
    $stmt = $pdo->prepare("UPDATE cart SET quantity = quantity + 1 WHERE id = ?");
    $stmt->execute([$cartItem['id']]);
} else {
    // Add the product to the cart
    $stmt = $pdo->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)");
    $stmt->execute([$userId, $productId]);
}

// Get the updated cart count
$stmt = $pdo->prepare("SELECT SUM(quantity) AS cartCount FROM cart WHERE user_id = ?");
$stmt->execute([$userId]);
$cartCount = $stmt->fetchColumn();

echo json_encode(['success' => true, 'message' => '<span style="color: #00796b;">Ürün başarıyla sepete eklendi!</span>']);
?>
