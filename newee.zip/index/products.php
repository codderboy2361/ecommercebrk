<!-- products.php -->
<?php
require '../admin/db.php'; // Include database connection
session_start();

// Fetch all products from the database
$stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
$products = $stmt->fetchAll();

// Fetch cart count for logged-in users
$cartCount = 0;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT SUM(quantity) AS cartCount FROM cart WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $cartCount = $stmt->fetchColumn() ?? 0;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ürünler | Çizgili Kareli</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: 'Quicksand', sans-serif;
      background: linear-gradient(135deg, rgb(139, 219, 209), rgb(139, 219, 209));
      color: #333;
    }

    .product-card {
      display: inline-block;
      width: 210px;
      margin: 15px;
      vertical-align: top;
      text-align: center;
      background-color: #e0f2f1; /* Light teal */
      border: 3px solid #f1f1f1;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease, border-color 0.3s ease;
    }

    .product-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
      border-color: #00796b;
    }

    .product-card img {
      max-width: 100%;
      height: auto;
      border-radius: 10px 10px 0 0;
    }

    .product-card h3 {
      font-size: 1.2rem;
      color: #333;
      margin: 10px 0;
    }

    .product-card p {
      font-size: 1rem;
      color: #00796b;
      font-weight: bold;
      margin: 5px 0;
    }

    .product-card .cart-controls {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 10px;
      margin-top: 10px;
    }

    .product-card .cart-controls button {
      background-color: #00796b; /* Teal */
      color: white;
      border: none;
      padding: 5px 10px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 1rem;
      transition: background-color 0.3s ease;
    }

    .product-card .cart-controls button:hover {
      background-color: #004d40; /* Dark teal */
    }

    .product-card .cart-controls span {
      font-size: 1.2rem;
      font-weight: bold;
      color: #333;
    }
  </style>
</head>
<body>
  <?php include('header.php'); ?>

  <section id="urunler" class="products-section">
    <div class="container" style="display: flex; flex-wrap: wrap; justify-content: center;">
      <h2 class="section-title" style="width: 100%; text-align: center;">Popüler Ürünler</h2>
      <div class="product-list" style="display: flex; flex-wrap: wrap; justify-content: center; gap: 20px;">
        <?php foreach ($products as $product): ?>
          <div class="product-card" data-product-id="<?= htmlspecialchars($product['id']) ?>" onclick="redirectToProduct(<?= htmlspecialchars($product['id']) ?>)">
            <img src="<?= htmlspecialchars($product['img']) ?>" alt="<?= htmlspecialchars($product['title']) ?>">
            <h3><?= htmlspecialchars($product['title']) ?></h3>
            <p>₺<?= number_format($product['price'], 2, ',', '.') ?></p>
            <div class="cart-controls">
              <button onclick="addToCart(<?= htmlspecialchars($product['id']) ?>, <?= $product['price'] ?>); event.stopPropagation();">Sepete Ekle</button>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php include('footer.php'); ?>

  <script>
    function redirectToProduct(productId) {
        window.location.href = `product.php?id=${productId}`;
    }

    function addToCart(productId, price) {
        const userId = <?= json_encode($_SESSION['user_id'] ?? null) ?>;

        if (!userId) {
            alert('Lütfen önce giriş yapın.');
            window.location.href = 'login.php';
            return;
        }

        fetch('add-to-cart.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId, productId, price })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateCartControls(productId, data.quantity || 1); // Ensure quantity is initialized
                updateCartCount(data.cartCount);
                showNotification('Ürün başarıyla sepete eklendi!');
            } else {
                showNotification('Ürün sepete eklenirken bir hata oluştu.', true);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('Bir hata oluştu.', true);
        });
    }

    function updateCartControls(productId, quantity) {
        const productCard = document.querySelector(`.product-card[data-product-id="${productId}"]`);
        if (productCard) {
            const cartControls = productCard.querySelector('.cart-controls');
            cartControls.innerHTML = `
                <button onclick="addToCart(${productId}, 0); event.stopPropagation();">Sepete Ekle</button>
            `;
        }
    }

    function updateCartCount(cartCount) {
        const cartCountElement = document.getElementById('cart-count');
        if (cartCountElement) {
            cartCountElement.textContent = `(${cartCount})`;
        }
    }

    function showNotification(message, isError = false) {
        const notification = document.createElement('div');
        notification.textContent = message;
        notification.style.position = 'fixed';
        notification.style.top = '50%';
        notification.style.left = '50%';
        notification.style.transform = 'translate(-50%, -50%)';
        notification.style.backgroundColor = isError ? '#00796b' : '#00796b';
        notification.style.color = 'white';
        notification.style.padding = '20px 30px';
        notification.style.borderRadius = '8px';
        notification.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
        notification.style.fontSize = '1.2rem';
        notification.style.textAlign = 'center';
        notification.style.zIndex = '1000';
        document.body.appendChild(notification);

        setTimeout(() => {
            document.body.removeChild(notification);
        }, 3000);
    }
  </script>
</body>
</html>