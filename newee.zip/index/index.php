<!-- index.php -->
<?php
// URL'yi al
$url = isset($_GET['url']) ? $_GET['url'] : '';

// URL'yi parçalara ayır
$urlParts = explode('/', trim($url, '/'));

// Örneğin /urun/3/ayakkabi gibi bir URL gelirse:
$page = isset($urlParts[0]) ? $urlParts[0] : '';
$id = isset($urlParts[1]) ? $urlParts[1] : '';
$slug = isset($urlParts[2]) ? $urlParts[2] : '';

// Yönlendirme
if ($page == 'urun' && is_numeric($id)) {
    // Mesela bir ürün sayfasına git
    include 'products.php';
} elseif ($page == 'urunler') {
    // Tüm ürünler listesi
    include 'products.php';
} elseif ($page == '') {
    // Ana sayfa
    include 'home.php';
} else {
    // 404 Sayfası
    include '404.php';
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Çizgili Kareli | Hediyelik Dünyası</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
  <style>
  body {
    font-family: 'Quicksand', sans-serif;
    background: linear-gradient(135deg, #e0f2f1, #b2dfdb); /* Light teal gradient */
    color: #2c3e50; /* Navy blue */
  }

  .hero {
    text-align: center;
    padding: 60px 20px;
    background: linear-gradient(135deg, #00796b, #004d40); /* Teal gradient */
    color: white;
    border-bottom: 5px solid #004d40; /* Dark teal */
  }

  .hero h1 {
    font-size: 2.5rem;
    margin-bottom: 20px;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
  }

  .hero p {
    font-size: 1.2rem;
    margin-bottom: 30px;
  }

  .btn-primary {
    background-color: white;
    color: #00796b; /* Teal */
    padding: 10px 20px;
    border: 2px solid white;
    border-radius: 5px;
    font-weight: bold;
    text-decoration: none;
    transition: all 0.3s ease;
  }

  .btn-primary:hover {
    background-color: #00796b; /* Teal */
    color: white;
    border-color: #004d40; /* Dark teal */
  }

  .featured-products {
    padding: 40px 20px;
    text-align: center;
  }

  .featured-products h2 {
    font-size: 2rem;
    color: #00796b; /* Teal */
    margin-bottom: 20px;
    text-transform: uppercase;
    text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
  }

  .products-grid {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
  }

  .product-card {
    display: inline-block;
    width: 210px;
    text-align: center;
    background-color: #e0f2f1; /* Light teal */
    border: 3px solid #f1f1f1;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease, border-color 0.3s ease;
  }

  .product-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    border-color: #00796b; /* Teal */
  }

  .product-card img {
    max-width: 100%;
    height: auto;
    border-radius: 10px 10px 0 0;
  }

  .product-card h2 {
    font-size: 1.2rem;
    color: #2c3e50; /* Navy blue */
    margin: 10px 0;
  }

  .product-card p {
    font-size: 1rem;
    color: #00796b; /* Teal */
    font-weight: bold;
    margin: 5px 0;
  }

  .product-card a {
    display: inline-block;
    background-color: #00796b; /* Teal */
    color: white;
    padding: 8px 12px;
    border-radius: 5px;
    text-decoration: none;
    font-size: 0.9rem;
    transition: all 0.3s ease;
  }

  .product-card a:hover {
    background-color: white;
    color: #00796b; /* Teal */
    border: 2px solid #00796b; /* Teal */
  }
  </style>
</head>
<body>
  <?php include('header.php'); ?>

  <main>
    <section class="hero-slider">
      <div class="slider-container">
        <?php
        $sliderStmt = $pdo->query("SELECT * FROM slider ORDER BY id ASC");
        $sliderItems = $sliderStmt->fetchAll(PDO::FETCH_ASSOC);
        ?>
        <?php foreach ($sliderItems as $slider): ?>
          <div class="slide">
            <img src="<?= htmlspecialchars($slider['img']) ?>" alt="Slider Image">
            <div class="slide-text">
              <h2><?= htmlspecialchars($slider['title']) ?></h2>
              <p><?= htmlspecialchars($slider['subtitle']) ?></p>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <div class="slider-arrows">
        <button id="prev-slide">&#10094;</button>
        <button id="next-slide">&#10095;</button>
      </div>
      <div class="slider-pagination">
        <?php foreach ($sliderItems as $index => $slider): ?>
          <span class="<?= $index === 0 ? 'active' : '' ?>" data-index="<?= $index ?>"></span>
        <?php endforeach; ?>
      </div>
    </section>

    <section class="featured-products">
      <h2>Öne Çıkan Ürünler</h2>
      <div class="products-grid">
        <?php
        require '../admin/db.php'; // Include database connection

        // Fetch 4 random products from the database
        $stmt = $pdo->query("SELECT * FROM products ORDER BY RAND() LIMIT 4");
        $featuredProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        ?>
        <?php foreach ($featuredProducts as $product): ?>
          <div class="product-card">
            <img src="<?= htmlspecialchars($product['img']) ?>" alt="<?= htmlspecialchars($product['title']) ?>">
            <h2><?= htmlspecialchars($product['title']) ?></h2>
            <p class="price">₺<?= number_format($product['price'], 2, ',', '.') ?></p>
            <a href="product.php?id=<?= $product['id'] ?>" class="btn-primary">İncele</a>
          </div>
        <?php endforeach; ?>
      </div>
      <div style="text-align: center; margin-top: 40px;">
        <a href="products.php" class="btn-primary" style="padding: 10px 20px; text-decoration: none;">Daha Fazla Ürün</a>
      </div>
    </section>
  </main>

  <style>
    .hero-slider {
      margin: 20px 0;
      overflow: hidden;
      position: relative;
      height: 300px;
    }

    .slider-container {
      display: flex;
      transition: transform 1s ease-in-out; /* Slower transition */
      height: 100%;
    }

    .slide {
      min-width: 100%;
      box-sizing: border-box;
      height: 100%;
      position: relative;
    }

    .slide img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    .slide::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.4); /* Semi-transparent black overlay */
      z-index: 1;
    }

    .slide-text {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      text-align: center;
      color: white;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
      z-index: 2; /* Ensure text is above the overlay */
    }

    .slide-text h2 {
      font-size: 2rem;
      margin-bottom: 10px;
    }

    .slide-text p {
      font-size: 1.2rem;
    }

    .slider-arrows {
      position: absolute;
      top: 50%;
      width: 100%;
      display: flex;
      justify-content: space-between;
      transform: translateY(-50%);
      z-index: 3;
    }

    .slider-arrows button {
      background: rgba(0, 0, 0, 0.5);
      color: white;
      border: none;
      padding: 10px 15px;
      cursor: pointer;
      font-size: 1.5rem;
      border-radius: 50%;
      transition: background 0.3s ease;
    }

    .slider-arrows button:hover {
      background: rgba(0, 0, 0, 0.8);
    }

    .slider-pagination {
      position: absolute;
      bottom: 10px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      gap: 10px;
      z-index: 3;
    }

    .slider-pagination span {
      width: 10px;
      height: 10px;
      background: rgba(255, 255, 255, 0.5);
      border-radius: 50%;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .slider-pagination span.active {
      background: white;
    }
  </style>

  <script>
    const sliderContainer = document.querySelector('.slider-container');
    const slides = document.querySelectorAll('.slide');
    const prevButton = document.getElementById('prev-slide');
    const nextButton = document.getElementById('next-slide');
    const paginationDots = document.querySelectorAll('.slider-pagination span');
    let currentIndex = 0;

    function updateSlider() {
      sliderContainer.style.transform = `translateX(-${currentIndex * 100}%)`;
      paginationDots.forEach(dot => dot.classList.remove('active'));
      paginationDots[currentIndex].classList.add('active');
    }

    function showNextSlide() {
      currentIndex = (currentIndex + 1) % slides.length;
      updateSlider();
    }

    function showPrevSlide() {
      currentIndex = (currentIndex - 1 + slides.length) % slides.length;
      updateSlider();
    }

    paginationDots.forEach(dot => {
      dot.addEventListener('click', () => {
        currentIndex = parseInt(dot.dataset.index);
        updateSlider();
      });
    });

    nextButton.addEventListener('click', showNextSlide);
    prevButton.addEventListener('click', showPrevSlide);

    setInterval(showNextSlide, 5000); // Slower automatic transition
  </script>

  <?php include('footer.php'); ?>
</body>
</html>

