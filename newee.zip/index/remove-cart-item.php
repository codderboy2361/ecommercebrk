<?php
require '../admin/db.php';

$data = json_decode(file_get_contents('php://input'), true);
$productId = $data['productId'] ?? null;
$userId = $data['userId'] ?? null;

if (!$productId || !$userId) {
    echo json_encode(['success' => false, 'message' => 'Eksik parametreler.']);
    exit;
}

$stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
$stmt->execute([$userId, $productId]);

echo json_encode(['success' => true, 'message' => '<span style="color: #00796b;">Ürün başarıyla kaldırıldı!</span>']);
?>
