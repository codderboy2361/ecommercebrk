<?php
require '../admin/db.php'; // Reuse the admin database connection
?>
