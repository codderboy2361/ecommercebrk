<!-- product.php -->
<?php
require '../admin/db.php'; // Include database connection

$productId = $_GET['id'] ?? null; // Use 'id' as the query parameter for consistency

if (!$productId) {
    echo "<p style='text-align:center; margin-top:100px;'>Ürün bulunamadı.</p>";
    exit;
}

// Fetch product details from the database
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$productId]);
$product = $stmt->fetch();

if (!$product) {
    echo "<p style='text-align:center; margin-top:100px;'>Ürün bulunamadı.</p>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($product['title']) ?> | Çizgili Kareli</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .product-detail {
      background-color: #eaf6f6; /* Light teal */
      padding: 60px 0;
    }
    .product-detail-wrapper {
      display: flex;
      flex-wrap: wrap;
      gap: 40px;
      max-width: 1200px;
      margin: auto;
      align-items: flex-start;
    }
    .product-detail-wrapper img {
      width: 100%;
      max-width: 500px;
      border-radius: 10px;
    }
    .product-info {
      flex: 1;
      min-width: 280px;
    }
    .product-info h1 {
      font-size: 2rem;
      margin-bottom: 15px;
    }
    .product-info .price {
      color: #00796b;
      font-size: 1.5rem;
      margin-bottom: 10px;
    }
    .product-info p {
      font-size: 1rem;
      margin-bottom: 20px;
      line-height: 1.6;
    }
    .btn-secondary {
      background-color: #00796b; /* Teal */
      color: #fff;
      padding: 12px 24px;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <?php include('header.php'); ?>
  <main class="product-detail">
    <div class="container">
      <div class="product-detail-wrapper">
        <img src="<?= htmlspecialchars($product['img']) ?>" alt="<?= htmlspecialchars($product['title']) ?>">
        <div class="product-info">
          <h1><?= htmlspecialchars($product['title']) ?></h1>
          <p class="price">₺<?= number_format($product['price'], 2, ',', '.') ?></p>
          <p><?= htmlspecialchars($product['description'] ?? 'Bu ürün için açıklama bulunmamaktadır.') ?></p>
          <button class="btn-secondary" onclick="addToCart(<?= htmlspecialchars($product['id']) ?>, <?= $product['price'] ?>)">Sepete Ekle</button>
        </div>
      </div>
    </div>
  </main>
  <?php include('footer.php'); ?>

  <script>
    function addToCart(productId, price) {
      const userId = <?= json_encode($_SESSION['user_id'] ?? null) ?>;

      if (!userId) {
        alert('Lütfen önce giriş yapın.');
        window.location.href = 'login.php';
        return;
      }

      fetch('add-to-cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, productId, price })
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          alert('Ürün başarıyla sepete eklendi!');
        } else {
          alert('Ürün sepete eklenirken bir hata oluştu.');
        }
      })
      .catch(error => console.error('Error:', error));
    }
  </script>
</body>
</html>
