<?php
require '../admin/db.php';

$userId = filter_input(INPUT_GET, 'userId', FILTER_VALIDATE_INT);

if (!$userId) {
    echo json_encode(['success' => false, 'message' => 'Kullanıcı ID eksik veya geçersiz.']);
    exit;
}

// Fetch cart items along with product details
$stmt = $pdo->prepare("
    SELECT 
        c.product_id, 
        p.title, 
        p.price, 
        p.img, 
        c.quantity 
    FROM cart c 
    JOIN products p ON c.product_id = p.id 
    WHERE c.user_id = ?
");
$stmt->execute([$userId]);
$cartItems = $stmt->fetchAll();

echo json_encode(['success' => true, 'cartItems' => $cartItems]);
?>
