<!-- footer.php -->
<footer class="main-footer" style="background-color: #e0f2f1; color: #2c3e50;">
  <div class="container">
    <p>&copy; 2025 Çizgili Kareli | Renkli fikirlerin adresi.</p>
  </div>
</footer>
