<?php
require 'db.php'; // Include database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $price = $_POST['price'] ?? 0;
    $category = $_POST['category'] ?? '';
    $img = $_POST['img'] ?? '';

    if ($title && $price && $category && $img) {
        $stmt = $pdo->prepare("INSERT INTO products (title, price, category, img) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$title, $price, $category, $img])) {
            header('Location: admin-product.php'); // Redirect to product list
            exit;
        } else {
            echo '<script>alert("Ürün eklenirken bir hata oluştu.");</script>';
        }
    } else {
        echo '<script>alert("Lütfen tüm alanları doldurun.");</script>';
    }
}
?>
