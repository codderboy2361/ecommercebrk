<?php
require 'db.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$orderId = $_GET['order_id'] ?? null;

if (!$orderId) {
    echo 'Sipariş ID eksik.';
    exit;
}

// Fetch order details
$stmt = $pdo->prepare("
    SELECT o.id AS order_id, o.total_price, o.created_at, u.username, u.email, o.status 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    WHERE o.id = ?
");
$stmt->execute([$orderId]);
$order = $stmt->fetch();

if (!$order) {
    echo 'Sipariş bulunamadı.';
    exit;
}

// Fetch order items
$stmt = $pdo->prepare("
    SELECT oi.product_id, p.title, oi.quantity, oi.price 
    FROM order_items oi 
    JOIN products p ON oi.product_id = p.id 
    WHERE oi.order_id = ?
");
$stmt->execute([$orderId]);
$orderItems = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sipariş Detayları</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Quicksand', sans-serif;
            background: linear-gradient(135deg, #fce4ec, #f8bbd0);
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #e91e63;
            margin-bottom: 20px;
        }

        p {
            font-size: 1rem;
            margin: 10px 0;
        }

        p strong {
            color: #e91e63;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table th, table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #e91e63;
            color: white;
        }

        table tr:last-child td {
            border-bottom: none;
        }

        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #e91e63;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            text-align: center;
            transition: background-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #d81b60;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Sipariş Detayları</h1>
        <p><strong>Sipariş ID:</strong> <?= $order['order_id'] ?></p>
        <p><strong>Kullanıcı:</strong> <?= htmlspecialchars($order['username']) ?> (<?= htmlspecialchars($order['email']) ?>)</p>
        <p><strong>Toplam Fiyat:</strong> ₺<?= number_format($order['total_price'], 2, ',', '.') ?></p>
        <p><strong>Tarih:</strong> <?= $order['created_at'] ?></p>
        <p><strong>Durum:</strong> <?= $order['status'] ?></p>

        <h2>Ürünler</h2>
        <table>
            <thead>
                <tr>
                    <th>Ürün Adı</th>
                    <th>Miktar</th>
                    <th>Birim Fiyat</th>
                    <th>Toplam</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orderItems as $item): ?>
                    <tr>
                        <td><?= htmlspecialchars($item['title']) ?></td>
                        <td><?= $item['quantity'] ?></td>
                        <td>₺<?= number_format($item['price'], 2, ',', '.') ?></td>
                        <td>₺<?= number_format($item['price'] * $item['quantity'], 2, ',', '.') ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <a href="admin_panel.php" class="back-button">Geri Dön</a>
    </div>
</body>
</html>
