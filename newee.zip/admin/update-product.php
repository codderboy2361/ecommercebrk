<?php
require 'db.php';

$id = $_POST['id'];
$title = $_POST['title'];
$price = $_POST['price'];
$category = $_POST['category'];
$img = $_POST['img'];

$stmt = $pdo->prepare("UPDATE products SET title = ?, price = ?, category = ?, img = ? WHERE id = ?");
$stmt->execute([$title, $price, $category, $img, $id]);

header("Location: admin-product.php");
exit;
?>
