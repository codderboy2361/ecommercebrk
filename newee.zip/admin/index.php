<?php
// Redirect to admin-product.php
header("Location: admin-product.php");
exit;
