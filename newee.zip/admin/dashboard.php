<?php
require 'db.php';
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Fetch daily total orders and revenue
$stmt = $pdo->query("
    SELECT COUNT(*) AS total_orders, SUM(total_price) AS total_revenue 
    FROM orders 
    WHERE DATE(created_at) = CURDATE()
");
$stats = $stmt->fetch();
$totalOrders = $stats['total_orders'] ?? 0;
$totalRevenue = $stats['total_revenue'] ?? 0;
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include('header.php'); ?>

    <div class="container">
        <h1>Dashboard</h1>
        <div class="stats">
            <div class="stat-card">
                <h2><?= $totalOrders ?></h2>
                <p>Bugünkü Siparişler</p>
            </div>
            <div class="stat-card">
                <h2>₺<?= number_format($totalRevenue, 2, ',', '.') ?></h2>
                <p>Bugünkü Gelir</p>
            </div>
        </div>

        <canvas id="revenueChart"></canvas>
    </div>

    <script>
        const ctx = document.getElementById('revenueChart').getContext('2d');
        const revenueChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Bugünkü Siparişler', 'Bugünkü Gelir'],
                datasets: [{
                    label: 'İstatistikler',
                    data: [<?= $totalOrders ?>, <?= $totalRevenue ?>],
                    backgroundColor: ['#007bff', '#28a745'],
                    borderColor: ['#0056b3', '#1e7e34'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
