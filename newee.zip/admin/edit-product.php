<?php
require 'db.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$productId = $_GET['id'] ?? null;

if (!$productId) {
    echo "Ürün ID eksik.";
    exit;
}

// Fetch product details
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$productId]);
$product = $stmt->fetch();

if (!$product) {
    echo "Ürün bulunamadı.";
    exit;
}

// Handle product update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $imagePath = $product['img'];

    // Handle file upload
    if (isset($_FILES['img']) && $_FILES['img']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../index/img/';
        $fileName = basename($_FILES['img']['name']);
        $filePath = $uploadDir . $fileName;

        // Ensure the upload directory exists
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        if (move_uploaded_file($_FILES['img']['tmp_name'], $filePath)) {
            $imagePath = 'img/' . $fileName;
        }
    }

    // Update product details in the database
    $stmt = $pdo->prepare("UPDATE products SET title = ?, price = ?, category = ?, description = ?, img = ? WHERE id = ?");
    $stmt->execute([$title, $price, $category, $description, $imagePath, $productId]);

    header("Location: admin_panel.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ürün Düzenle</title>
    <style>
        body {
            font-family: 'Quicksand', sans-serif;
            background: linear-gradient(135deg, #fce4ec, #f8bbd0);
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .edit-product-container {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
        }

        .edit-product-container h1 {
            text-align: center;
            color: #e91e63;
            margin-bottom: 20px;
        }

        .edit-product-container form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .edit-product-container label {
            font-weight: bold;
            color: #555;
        }

        .edit-product-container input,
        .edit-product-container textarea {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }

        .edit-product-container textarea {
            resize: none;
        }

        .edit-product-container img {
            width: 100px;
            border-radius: 5px;
            margin-top: 10px;
        }

        .edit-product-container button {
            padding: 10px;
            background: #e91e63;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .edit-product-container button:hover {
            background: #d81b60;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            text-align: center;
            color: #e91e63;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            color: #d81b60;
        }
    </style>
</head>
<body>
    <div class="edit-product-container">
        <h1>Ürün Düzenle</h1>
        <form method="POST" enctype="multipart/form-data">
            <label for="title">Ürün Adı:</label>
            <input type="text" id="title" name="title" value="<?= htmlspecialchars($product['title']) ?>" required>

            <label for="price">Fiyat:</label>
            <input type="number" id="price" name="price" step="0.01" value="<?= htmlspecialchars($product['price']) ?>" required>

            <label for="category">Kategori:</label>
            <input type="text" id="category" name="category" value="<?= htmlspecialchars($product['category']) ?>" required>

            <label for="description">Açıklama:</label>
            <textarea id="description" name="description" rows="4" required><?= htmlspecialchars($product['description']) ?></textarea>

            <label for="img">Resim:</label>
            <input type="file" id="img" name="img" accept="image/*">
            <img src="../index/<?= htmlspecialchars($product['img']) ?>" alt="<?= htmlspecialchars($product['title']) ?>">

            <button type="submit">Kaydet</button>
        </form>
        <a href="admin_panel.php" class="back-link">Geri Dön</a>
    </div>
</body>
</html>
