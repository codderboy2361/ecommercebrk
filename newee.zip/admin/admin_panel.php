<!-- filepath: c:\AppServ\www\htdocs\newee\admin\admin_panel.php -->
<?php
require 'db.php';
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Fetch daily total orders and revenue
$stmt = $pdo->query("
    SELECT COUNT(*) AS total_orders, SUM(total_price) AS total_revenue 
    FROM orders 
    WHERE DATE(created_at) = CURDATE()
");
$stats = $stmt->fetch();
$totalOrders = $stats['total_orders'] ?? 0;
$totalRevenue = $stats['total_revenue'] ?? 0;

// Fetch products
$productStmt = $pdo->query("SELECT * FROM products");
$products = $productStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch orders
$orderStmt = $pdo->query("
    SELECT o.id AS order_id, o.total_price, o.created_at, u.username, u.email, o.status 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    ORDER BY o.created_at DESC
");
$orders = $orderStmt->fetchAll();

// Handle product addition with file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $title = $_POST['title'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $description = $_POST['description'];

    // Handle file upload
    if (isset($_FILES['img']) && $_FILES['img']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../index/img/';
        $fileName = basename($_FILES['img']['name']);
        $filePath = $uploadDir . $fileName;

        // Ensure the upload directory exists
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Move the uploaded file to the target directory
        if (move_uploaded_file($_FILES['img']['tmp_name'], $filePath)) {
            // Save product details in the database
            $stmt = $pdo->prepare("INSERT INTO products (title, price, category, img, description) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$title, $price, $category, 'img/' . $fileName, $description]);
            header("Location: admin_panel.php");
            exit;
        } else {
            $errorMessage = "Dosya yüklenirken bir hata oluştu.";
        }
    } else {
        $errorMessage = "Geçerli bir resim dosyası yükleyin.";
    }
}

// Handle product deletion
if (isset($_GET['delete_product'])) {
    $id = $_GET['delete_product'];
    $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin_panel.php");
    exit;
}

// Handle order status update via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_update_order_status'])) {
    $orderId = $_POST['order_id'];
    $status = $_POST['status'];

    if ($orderId && $status) {
        // Update the order status in the database
        $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$status, $orderId]);

        // Fetch the updated order details
        $stmt = $pdo->prepare("SELECT id, status FROM orders WHERE id = ?");
        $stmt->execute([$orderId]);
        $updatedOrder = $stmt->fetch();

        if ($updatedOrder) {
            echo json_encode(['success' => true, 'message' => 'Sipariş durumu güncellendi.', 'updatedOrder' => $updatedOrder]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Sipariş bulunamadı.']);
        }
        exit;
    }
    echo json_encode(['success' => false, 'message' => 'Güncelleme başarısız.']);
    exit;
}

// Handle slider settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_slider'])) {
    $sliderData = $_POST['slider'] ?? [];
    $uploadDir = '../index/img/';

    foreach ($sliderData as $index => $slider) {
        $title = $slider['title'];
        $subtitle = $slider['subtitle'];
        $imagePath = $slider['existing_img'];

        // Handle file upload for new images
        if (isset($_FILES['slider']['name'][$index]['img']) && $_FILES['slider']['error'][$index]['img'] === UPLOAD_ERR_OK) {
            $fileName = basename($_FILES['slider']['name'][$index]['img']);
            $filePath = $uploadDir . $fileName;

            // Ensure the upload directory exists
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            if (move_uploaded_file($_FILES['slider']['tmp_name'][$index]['img'], $filePath)) {
                $imagePath = 'img/' . $fileName;
            }
        }

        // Update slider data in the database
        $stmt = $pdo->prepare("UPDATE slider SET title = ?, subtitle = ?, img = ? WHERE id = ?");
        $stmt->execute([$title, $subtitle, $imagePath, $index]);
    }

    $successMessage = "Slider ayarları başarıyla güncellendi.";
}

// Handle adding a new slider
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_slider'])) {
    $title = $_POST['new_slider_title'] ?? '';
    $subtitle = $_POST['new_slider_subtitle'] ?? '';
    $imagePath = '';

    // Handle file upload for the new slider
    if (isset($_FILES['new_slider_img']) && $_FILES['new_slider_img']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../index/img/';
        $fileName = basename($_FILES['new_slider_img']['name']);
        $filePath = $uploadDir . $fileName;

        // Ensure the upload directory exists
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        if (move_uploaded_file($_FILES['new_slider_img']['tmp_name'], $filePath)) {
            $imagePath = 'img/' . $fileName;
        }
    }

    if ($title && $subtitle && $imagePath) {
        $stmt = $pdo->prepare("INSERT INTO slider (title, subtitle, img) VALUES (?, ?, ?)");
        $stmt->execute([$title, $subtitle, $imagePath]);
        $successMessage = "Yeni slider başarıyla eklendi.";
    } else {
        $errorMessage = "Tüm alanları doldurun ve geçerli bir resim yükleyin.";
    }
}

// Fetch slider data
$sliderStmt = $pdo->query("SELECT * FROM slider ORDER BY id ASC");
$sliderItems = $sliderStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            background-color: #00796b; /* Teal */
            color: white;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar a {
            text-decoration: none;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            cursor: pointer;
        }

        .sidebar a:hover, .sidebar a.active {
            background-color: #004d40; /* Dark teal */
        }

        .content {
            flex: 1;
            padding: 20px;
        }

        .hidden {
            display: none;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        .stats {
            display: flex;
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-card {
            flex: 1;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .stat-card h2 {
            font-size: 2rem;
            color: #007bff;
        }

        .stat-card p {
            font-size: 1.2rem;
            color: #555;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        form {
            margin-bottom: 20px;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        input, button, select {
            padding: 10px;
            margin: 10px 0;
            width: 100%;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            background-color: #00796b; /* Teal */
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #004d40; /* Dark teal */
        }

        canvas {
            max-width: 100%;
            margin: auto;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                flex-direction: row;
                justify-content: space-around;
                padding: 10px;
            }

            .content {
                padding: 10px;
            }

            .stats {
                flex-direction: column;
            }
        }

        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #28a745;
            color: white;
            padding: 15px 20px;
            border-radius: 5px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            display: none;
            z-index: 1000;
        }

        .notification.error {
            background-color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <a href="#dashboard" class="menu-link active" onclick="showSection('dashboard')">Dashboard</a>
        <a href="#products" class="menu-link" onclick="showSection('products')">Ürün Yönetimi</a>
        <a href="#orders" class="menu-link" onclick="showSection('orders')">Sipariş Yönetimi</a>
        <a href="#slider-settings" class="menu-link" onclick="showSection('slider-settings')">Slider Ayarları</a>
        <a href="logout.php">Çıkış Yap</a>
    </div>

    <div class="content">
        <!-- Dashboard Section -->
        <div id="dashboard" class="section">
            <h1>Dashboard</h1>
            <div class="stats">
                <div class="stat-card">
                    <h2><?= $totalOrders ?></h2>
                    <p>Bugünkü Siparişler</p>
                </div>
                <div class="stat-card">
                    <h2>₺<?= number_format($totalRevenue, 2, ',', '.') ?></h2>
                    <p>Bugünkü Gelir</p>
                </div>
            </div>
            <canvas id="revenueChart"></canvas>
        </div>

        <!-- Product Management Section -->
        <div id="products" class="section hidden">
            <h1>Ürün Yönetimi</h1>
            <form method="post" enctype="multipart/form-data">
                <h3>Ürün Ekle</h3>
                <?php if (isset($errorMessage)): ?>
                    <p style="color: red;"><?= htmlspecialchars($errorMessage) ?></p>
                <?php endif; ?>
                <input type="text" name="title" placeholder="Ürün Adı" required>
                <input type="number" step="0.01" name="price" placeholder="Fiyat" required>
                <input type="text" name="category" placeholder="Kategori" required>
                <textarea style="text-align: left;" name="description" placeholder="Ürün Açıklaması" rows="15" cols="170" required></textarea>
                <input type="file" name="img" accept="image/*" required>
                <button type="submit" name="add_product">Ürün Ekle</button>
            </form>

            <h3>Ürün Listesi</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ürün Adı</th>
                        <th>Fiyat</th>
                        <th>Kategori</th>
                        <th>Açıklama</th>
                        <th>Resim</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?= $product['id'] ?></td>
                            <td><?= htmlspecialchars($product['title']) ?></td>
                            <td>₺<?= number_format($product['price'], 2, ',', '.') ?></td>
                            <td><?= htmlspecialchars($product['category']) ?></td>
                            <td><?= htmlspecialchars($product['description']) ?></td>
                            <td><img src="../index/<?= htmlspecialchars($product['img']) ?>" alt="<?= htmlspecialchars($product['title']) ?>" style="width: 50px;"></td>
                            <td>
                                <a href="edit-product.php?id=<?= $product['id'] ?>" style="color: blue;">Düzenle</a> |
                                <a href="?delete_product=<?= $product['id'] ?>" onclick="return confirm('Bu ürünü silmek istediğinize emin misiniz?')" style="color: red;">Sil</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Order Management Section -->
        <div id="orders" class="section hidden">
            <h1>Sipariş Yönetimi</h1>
            <table>
                <thead>
                    <tr>
                        <th>Sipariş ID</th>
                        <th>Kullanıcı</th>
                        <th>E-posta</th>
                        <th>Toplam Fiyat</th>
                        <th>Tarih</th>
                        <th>Durum</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?= $order['order_id'] ?></td>
                            <td><?= htmlspecialchars($order['username']) ?></td>
                            <td><?= htmlspecialchars($order['email']) ?></td>
                            <td>₺<?= number_format($order['total_price'], 2, ',', '.') ?></td>
                            <td><?= $order['created_at'] ?></td>
                            <td>
                                <select onchange="updateOrderStatus(<?= $order['order_id'] ?>, this.value)">
                                    <option value="Hazırlanıyor" <?= $order['status'] === 'Hazırlanıyor' ? 'selected' : '' ?>>Hazırlanıyor</option>
                                    <option value="Kargoya Verildi" <?= $order['status'] === 'Kargoya Verildi' ? 'selected' : '' ?>>Kargoya Verildi</option>
                                    <option value="Teslim Edildi" <?= $order['status'] === 'Teslim Edildi' ? 'selected' : '' ?>>Teslim Edildi</option>
                                </select>
                            </td>
                            <td><a href="order-details.php?order_id=<?= $order['order_id'] ?>">Detaylar</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Slider Settings Section -->
        <div id="slider-settings" class="section hidden">
            <h1>Slider Ayarları</h1>
            <?php if (isset($successMessage)): ?>
                <p style="color: green;"><?= htmlspecialchars($successMessage) ?></p>
            <?php endif; ?>
            <?php if (isset($errorMessage)): ?>
                <p style="color: red;"><?= htmlspecialchars($errorMessage) ?></p>
            <?php endif; ?>
            <form method="POST" enctype="multipart/form-data">
                <?php foreach ($sliderItems as $slider): ?>
                    <div style="margin-bottom: 20px; border: 1px solid #ddd; padding: 15px; border-radius: 8px;">
                        <h3>Slider #<?= $slider['id'] ?></h3>
                        <label for="slider-title-<?= $slider['id'] ?>">Başlık:</label>
                        <input type="text" id="slider-title-<?= $slider['id'] ?>" name="slider[<?= $slider['id'] ?>][title]" value="<?= htmlspecialchars($slider['title']) ?>" required>

                        <label for="slider-subtitle-<?= $slider['id'] ?>">Alt Başlık:</label>
                        <input type="text" id="slider-subtitle-<?= $slider['id'] ?>" name="slider[<?= $slider['id'] ?>][subtitle]" value="<?= htmlspecialchars($slider['subtitle']) ?>" required>

                        <label for="slider-img-<?= $slider['id'] ?>">Resim:</label>
                        <input type="file" id="slider-img-<?= $slider['id'] ?>" name="slider[<?= $slider['id'] ?>][img]" accept="image/*">
                        <input type="hidden" name="slider[<?= $slider['id'] ?>][existing_img]" value="<?= htmlspecialchars($slider['img']) ?>">
                        <img src="../index/<?= htmlspecialchars($slider['img']) ?>" alt="Slider Image" style="width: 100px; margin-top: 10px;">
                    </div>
                <?php endforeach; ?>
                <button type="submit" name="update_slider">Kaydet</button>
            </form>

            <h2>Yeni Slider Ekle</h2>
            <form method="POST" enctype="multipart/form-data">
                <label for="new-slider-title">Başlık:</label>
                <input type="text" id="new-slider-title" name="new_slider_title" placeholder="Başlık" required>

                <label for="new-slider-subtitle">Alt Başlık:</label>
                <input type="text" id="new-slider-subtitle" name="new_slider_subtitle" placeholder="Alt Başlık" required>

                <label for="new-slider-img">Resim:</label>
                <input type="file" id="new-slider-img" name="new_slider_img" accept="image/*" required>

                <button type="submit" name="add_slider">+ Slider Ekle</button>
            </form>
        </div>
    </div>

    <div class="notification" id="notification"></div>

    <script>
        function showSection(sectionId) {
            document.querySelectorAll('.section').forEach(section => {
                section.classList.add('hidden');
            });
            document.getElementById(sectionId).classList.remove('hidden');

            document.querySelectorAll('.menu-link').forEach(link => {
                link.classList.remove('active');
            });
            document.querySelector(`.menu-link[href="#${sectionId}"]`).classList.add('active');
        }

        function updateOrderStatus(orderId, status) {
            fetch('admin_panel.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ajax_update_order_status: true, order_id: orderId, status })
            }).then(response => response.json())
              .then(data => alert(data.message));
        }

        const ctx = document.getElementById('revenueChart').getContext('2d');
        const revenueChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Bugünkü Siparişler', 'Bugünkü Gelir'],
                datasets: [{
                    label: 'İstatistikler',
                    data: [<?= $totalOrders ?>, <?= $totalRevenue ?>],
                    backgroundColor: ['#007bff', '#28a745'],
                    borderColor: ['#0056b3', '#1e7e34'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>