<!-- add-product.php -->
<?php
require 'db.php'; // Include database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $img = $_POST['img'];
    $description = $_POST['description'];

    $stmt = $pdo->prepare("INSERT INTO products (title, price, category, img, description) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$title, $price, $category, $img, $description]);

    header('Location: admin-product.php'); // Redirect to product list
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Yeni Ürün Ekle | Yönetici Paneli</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1>Yeni Ürün Ekle</h1>
  <form method="POST" action="">
    <label for="title">Ürün Adı:</label>
    <input type="text" id="title" name="title" required>
    
    <label for="price">Fiyat:</label>
    <input type="number" id="price" name="price" step="0.01" required>
    
    <label for="category">Kategori:</label>
    <input type="text" id="category" name="category" required>
    
    <label for="img">Resim URL:</label>
    <input type="text" id="img" name="img" required>
    
    <label for="description">Açıklama:</label>
    <textarea id="description" name="description" rows="4" required></textarea>
    
    <button type="submit">Ürün Ekle</button>
  </form>
</body>
</html>
